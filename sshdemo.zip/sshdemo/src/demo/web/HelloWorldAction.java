package demo.web;

import com.opensymphony.xwork2.Action;

public class HelloWorldAction implements Action {//ʵ��action�ӿ�

	private String content;
	
	
	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		content="Hello,world!";
		return Action.SUCCESS;
	}

	
}
